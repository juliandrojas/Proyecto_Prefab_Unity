﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class objetoEsfera : MonoBehaviour {
	public GameObject prefab;
	private int contador = 0;
	public float tiempoDestruir = 2f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyUp (KeyCode.I)) {
			contador = contador + 1;
			GameObject car = Instantiate (prefab, transform.position, transform.rotation) as GameObject;
			car.name = "Autox" + contador;
			//Destruimos el elemento
			Destroy(this.gameObject, tiempoDestruir);
		}
	}
}
